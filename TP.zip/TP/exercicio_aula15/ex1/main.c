#include <stdio.h>

typedef struct {
    int qtd;
    int cod;
} Produto;

void inserirProduto(Produto p[], int *qtd, Produto novo) {
    p[*qtd] = novo;
    (*qtd)++;
}

int main(){
    Produto p[100];
    int totalProdutos = 0;
    Produto prod1 = {10, 101};

    inserirProduto(p, &totalProdutos, prod1);
    printf("Produto inserido! Codigo: %d, Total na lista: %d\n", p[0].cod, totalProdutos);
    
    return 0;
}

