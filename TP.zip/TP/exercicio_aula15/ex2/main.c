#include <stdio.h>

typedef struct {
    int qtd;
    int cod;
} Produto;

int buscaLinear(Produto p[], int n, int cod) {
    for(int i = 0; i < n; i++) {
        if(p[i].cod == cod){
            return i;
        }
    }
    return -1;
}

int main(){
    Produto p[100];
    int totalProdutos = 0;
    Produto prod1 = {10, 101};

    inserirProduto(p, &totalProdutos, prod1);
    printf("Produto inserido! cod: %d, Total na lista: %d\n", p[0].cod, totalProdutos);
    
    return 0;
}

