#include <stdio.h>

int suape(int *p, int *q){
    int tmp = 0;
    tmp = *p;
    *p = *q;
    *q = tmp;
    printf("A = %d, B = %d", *p, *q);
}

int main(){
    int a, b;
    scanf("%d", &a);
    scanf("%d", &b);
    int *p = &a;
    int *q = &b;
    suape(&a, &b);
    return 0;
}