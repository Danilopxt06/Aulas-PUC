#include <stdio.h>

int verificar(int *p, int *q){
    int maior, menor;
    if (*p>*q){
        maior = *p;
        menor = *q;
    }
    else{
        maior = *q;
        menor = *p;
    }
    printf("maior = %d, menor = %d", maior, menor);
}

int main(){
    int a, b;
    scanf("%d", &a);
    scanf("%d", &b);
    int *p = &a;
    int *q = &b;
    verificar(p, q);
    return 0;
}