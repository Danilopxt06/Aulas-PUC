#include <stdio.h>

double mediav(int *p){
    int i, soma=0;
    for (i = 0; i < 5; i++){
        scanf("%d", p+i);
        soma = soma + *(p+i); 
    }
    return soma/5.0;
}

int main(){
    int v[10];
    printf("%.1f",mediav(v));
    return 0;
}