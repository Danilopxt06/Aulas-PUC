#include <stdio.h>

double pares(int *p){
    int i, cont=0;
    for (i = 0; i < 5; i++){
        scanf("%d", p+i);
        if (p+i%2==0){
            cont++;
        }
        
    }
    return cont;
}

int main(){
    int v[10];
    printf("%d", pares(v));
    return 0;
}