#include <stdio.h>

int dobrar(int *p){
    return *p * 2;
}

int main(){
    int n;
    scanf("%d", &n);
    int *p = &n;
    printf("%d", dobrar(p));
    return 0;
}