#include <stdio.h>

int meu_strlen(char *s){
    int cont = 0;
    while(*s != '\0'){
        cont++;
        s++;
    }
    return cont;
}

int main(){
    char str[10];
    scanf("%s", &str);
    char *s = str;
    printf("%d", meu_strlen(s));
    return 0;
}