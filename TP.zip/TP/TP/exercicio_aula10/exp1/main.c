#include <stdio.h>

int main(){
    char str[10];
    scanf("%s", &str);
    char *p = str;
    while(*p != '\0'){
        printf("%c\n", *p);
        p++;
    }
    return 0;
}