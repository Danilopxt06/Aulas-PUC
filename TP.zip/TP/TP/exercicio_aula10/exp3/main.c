#include <stdio.h>

int meu_strlen(char *s){
    int cont = 0;
    while(*s != '\0'){
        cont++;
        s++;
    }
    return cont;
}

void meu_strcpy(char *dest, char *orig){
    while(*orig != '\0'){
        *dest = *orig;
        dest++;
        orig++;
    }
    *dest = '\0';
}

int main(){
    char A[10], B[10];
    scanf("%s", &A);
    char *dest = &B;
    char *orig = &A;
    printf("%d", meu_strlen());
    meu_strcpy();
    return 0;
}