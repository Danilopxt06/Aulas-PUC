/*
Crie uma struct Cliente com:
- nome
- idade
- int ativo (1 ou 0)
Imprima "Ativo" ou "Inativo".
*/