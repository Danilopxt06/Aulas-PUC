#include <stdio.h>
#include <string.h>

struct Aluno{
    char nome[100];
    int idade;
    float media;
};

int main(){
    struct Aluno a1;
    strcpy(a1.nome, "Danilo");
    a1.idade = 20;
    a1.media = 7.5;

    printf("%s\n", a1.nome);
    printf("%d\n", a1.idade);
    printf("%.2f\n", a1.media);
    return 0;
}