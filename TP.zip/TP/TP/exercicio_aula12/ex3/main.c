#include <stdio.h>
#include <string.h>

typedef struct{
    char nome[100];
    float salario;
} Funcionario;

int main(){
    Funcionario f1;
    strcpy(f1.nome, "Danilo");
    f1.salario = 7500.5;

    printf("%s\n", f1.nome);
    printf("%.2f\n", f1.salario);
    return 0;
}