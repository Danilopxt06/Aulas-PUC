#include <stdio.h>
#include <string.h>

typedef struct{
    char nome[100];
    float preco;
} Produto;

int main(){
    Produto p1;
    Produto p2;
    Produto p3;
    float total;
    int i;

    strcpy(p1.nome, "Arroz");
    p1.preco = 10.0;

    strcpy(p2.nome, "Feijão");
    p2.preco = 5.0;

    strcpy(p3.nome, "Macaxeira");
    p3.preco = 2.0;

    Produto carrinho[3] = {p1, p2, p3};
    for(i=0; i<3; i++){
        total += carrinho[i].preco;
    }
    printf("%.2f\n", total);
    return 0;
}