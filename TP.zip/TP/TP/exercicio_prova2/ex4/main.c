#include <stdio.h>

int suap(int *p1, int *p2){
    int temp;
    temp = *p1;
    *p1 = *p2;
    *p2 = temp;

    printf("n1: %d, n2: %d\n", *p1, *p2);
}

int main(){
    int n1, n2;
    scanf("%d", &n1);
    scanf("%d", &n2);
    printf("n1: %d, n2: %d\n", n1, n2);
    
    int *p1 = &n1;
    int *p2 = &n2;
    suap(p1, p2);
    return 0;
}