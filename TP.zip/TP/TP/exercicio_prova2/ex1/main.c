#include <stdio.h>

int quad(int n){
    n = n*n;
    printf("%d", n);
}

int main(){
    int n;
    scanf("%d", &n);
    quad(n);
    return 0;
}