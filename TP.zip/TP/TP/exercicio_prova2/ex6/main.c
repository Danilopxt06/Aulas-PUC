#include <stdio.h>

int dob(int v[5]){
    int i;
    for (i = 0; i < 5; i++){
        printf("%d ", v[i] * 2);
    }
}

int main(){
    int v[5], i;
    for (i = 0; i < 5; i++){
        scanf("%d", &v[i]);
    }
    dob(v);
    
    return 0;
}