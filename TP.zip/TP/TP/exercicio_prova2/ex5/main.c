#include <stdio.h>

int prod(int *p1, int *p2){
    printf("%d", *p1 * *p2); 
}

int main(){
    int n1, n2;
    scanf("%d", &n1);
    scanf("%d", &n2);
    
    int *p1 = &n1;
    int *p2 = &n2;
    prod(p1, p2);
    return 0;
}