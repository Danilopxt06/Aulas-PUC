#include <stdio.h>

int alt(int *p){
    
    *p = 100;
}

int main(){
    int n;
    int *p = &n;

    scanf("%d", &n);
    printf("V1: %d\n", n);

    alt(p);
    printf("V2: %d\n", n);
    return 0;
}