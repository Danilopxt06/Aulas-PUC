#include <stdio.h>
#include <string.h>

void converte(char *p) {
    int i = 0;
    while(p[i] != '\0') {
        if(p[i] >= 'a' && p[i] <= 'z') {
            p[i] = p[i] - 32;
        }
        i++;
    }

    printf("%s", p);
}

int main() {
    char str[100];
    scanf("%s", str); 
    converte(str);
    return 0;
}