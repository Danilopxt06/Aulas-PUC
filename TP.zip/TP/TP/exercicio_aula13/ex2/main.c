#include <stdio.h>
#include <string.h>

int encontrar_substring(const char texto[], const char busca[]) {
    int n = strlen(texto);
    int m = strlen(busca);

    if (m > n) return -1;
    int i;
    for (i = 0; i <= n - m; i++) {
        int j;
        for (j = 0; j < m; j++) {
            if (texto[i + j] != busca[j]) {
                break; 
            }
        }
        if (j == m) {
            return i;
        }
    }
    return -1;
}

int main() {
    char texto[100];
    char busca[100];
    scanf("%s", texto);
    scanf("%s", busca);
    int posicao = encontrar_substring(texto, busca);
    if (posicao != -1) {
        printf("%d\n", posicao);
    } else {
        printf("-1\n");
    }

    return 0;
}