
#include <stdio.h>
#include <stdbool.h>
#include <string.h>

struct Carro{
    char marca[100];
    char ano[100];
    bool revisado;
};

int main() {
    struct Carro c1;
    
    strcpy(c1.marca, "Toyota");
    strcpy(c1.ano, "2004");
    c1.revisado = true;

    printf("Marca: %s\n", c1.marca);
    printf("Ano: %s\n", c1.ano);
    printf("Revisado: %s\n", c1.revisado ? "Sim" : "Nao");
    return 0;
}
