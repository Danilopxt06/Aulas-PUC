#include <stdio.h>
#include <stdbool.h>
#include <string.h>

typedef struct {
    char nome[100];
    int cod;
    int qtd;
    double preco;
    bool disp;
} Produto;

void cadastraprod(Produto *p) {
    strcpy(p->nome, "Teclado Gamer");
    p->cod = 1;
    p->qtd = 0;
    p->preco = 10.0;
}

void attproduto(Produto *p) {
    p->disp = p->qtd > 0;
    printf("Disponivel: %s\n", p->disp ? "Sim" : "Nao");
}

int main() {
    Produto p1;
    cadastraprod(&p1);
    attproduto(&p1);
    return 0;
}
