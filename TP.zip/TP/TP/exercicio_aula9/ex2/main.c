#include <stdio.h>
#include <string.h>

void copy(char str[], char strcop[]){
    int cont=0;
    scanf("%s", str);
    while(str[cont] != '\0'){
        strcop[cont] = str[cont];
        cont++;
    }
    strcop[cont] = '\0';
    printf("Original: %s\n", str);
    printf("Copia: %s\n", strcop);
}

int main(){
    char str[100];
    char strcop[100];
    copy(str, strcop);
    return 0;
}