#include <stdio.h>
#include <string.h>

char str[];

void contcar(){
    int cont=0;
    scanf("%s", &str);
    while(str[cont] != '\0'){
        cont++;
    }
    printf("%d", cont);
}

int main(){
    contcar();
    return 0;
}