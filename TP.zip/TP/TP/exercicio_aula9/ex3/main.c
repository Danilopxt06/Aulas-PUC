#include <stdio.h>
#include <string.h>

char str[];

void inv(){
    char tmp;
    scanf("%s", str);
    int i = 0;
    int j = strlen(str) - 1;
    while(i<j){
        tmp = str[i];
        str[i] = str[j];
        str[j] = tmp;
        i++;
        j--;
    }
    printf("%s\n", str);
}

int main(){
    inv();
    return 0;
}