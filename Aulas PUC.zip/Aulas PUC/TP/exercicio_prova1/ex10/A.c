#include "A.h"

int quad(int n){
    n = n*n;
    return n;
}