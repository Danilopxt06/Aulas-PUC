#include <stdio.h>
#include "A.h"

int main(){
    int n;
    scanf("%d", &n);
    printf("%d", quad(n));
    return 0;
}