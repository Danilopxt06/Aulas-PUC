#ifndef A_H
#define A_H

int quad(int n);

#endif