#include <stdio.h>

int main(){
    int n, i, maior=0;
    for ( i = 0; i < 5; i++)
    {
        scanf("%d", &n);
        if (n>maior)
        {
            maior=n;
        }
        
    }
    printf("%d", maior);
    return 0;
}