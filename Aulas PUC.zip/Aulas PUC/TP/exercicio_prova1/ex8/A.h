#ifndef A_H
#define A_H

int dobro(int n);

#endif