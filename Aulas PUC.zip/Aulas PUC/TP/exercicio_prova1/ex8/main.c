#include <stdio.h>
#include "A.h"

int main(){
    int n;
    scanf("%d", &n);
    printf("%d", dobro(n));
    return 0;
}