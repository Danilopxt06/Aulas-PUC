#include "A.h"

int dobro(int n){
    n = n*2;
    return n;
}