#include <stdio.h>

int main(){
    int n, i, cont=0;
    for ( i = 0; i < 4; i++)
    {
        scanf("%d", &n);
        if (n%2==0)
        {
            cont++;
        }
        
    }
    printf("%d", cont);
    return 0;
}