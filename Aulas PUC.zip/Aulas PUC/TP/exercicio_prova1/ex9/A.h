#ifndef A_H
#define A_H

int maior(int n1, int n2);

#endif