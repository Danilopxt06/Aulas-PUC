#include <stdio.h>
#include "A.h"

int main(){
    int n1, n2;
    scanf("%d", &n1);
    scanf("%d", &n2);
    printf("%d", maior(n1, n2));
    return 0;
}