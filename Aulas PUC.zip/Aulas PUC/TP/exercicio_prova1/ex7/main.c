#include <stdio.h>

int main(){
    int m[3][3], i, j, cont=0;
    for ( i = 0; i < 3; i++){
        for (j = 0; j < 3; j++){
            scanf("%d", &m[i][j]);
            if(m[i][j]>0){
                cont++;
            } 
        }
    }
    printf("%d", cont);
    return 0;
}