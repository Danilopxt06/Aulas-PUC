#include <stdio.h>

int main(){
    int n1, n2, soma=0, mult=0;
    scanf("%d", &n1);
    scanf("%d", &n2);
    soma=n1+n2;
    mult=n1*n2;
    printf("%d\n", soma);
    printf("%d\n", mult);

    return 0;
}