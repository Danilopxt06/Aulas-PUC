#include <stdio.h>

//Teste de função

float converte(float c){
    return (c * 1.8) + 32;
}

int main(){
    float t1;
    float t2;
    printf("Digite a temperatura em celcius: ");
    scanf("%f", &t1);
    t2 = converte(t1);
    printf("A temperatua em Fahrenheit: %.1f F\n", t2);
    return 0;
}