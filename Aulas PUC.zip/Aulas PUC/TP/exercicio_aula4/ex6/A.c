#include "A.h"
#include <stdio.h>

int par(int n){
    if (n==0){
         printf("ehPar");
    }
    else if (n==1){
        printf("ehImpar");
    }
    return par(n-2);
}