#ifndef A_H
#define A_H

int par(int n);

#endif