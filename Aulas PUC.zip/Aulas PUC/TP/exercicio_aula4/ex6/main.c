#include <stdio.h>
#include "A.h"

int main(){
    int n;
    scanf("%d", &n);
    printf("%d\n", par(n));
    return 0;
}