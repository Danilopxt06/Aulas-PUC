#ifndef A_H
#define A_H

int fibonacci(int n);

#endif