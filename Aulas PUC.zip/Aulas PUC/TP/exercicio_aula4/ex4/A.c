#include "A.h"

int pot(int n){
    if (n<=1){
        return n;
    }
    return n * pot(n - 1);
}