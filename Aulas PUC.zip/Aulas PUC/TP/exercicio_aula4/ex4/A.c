#include "A.h"

int pot(int base, int exp){
    if (exp==0){
        return 1;
    }
    return base * pot(base, exp-1);
}