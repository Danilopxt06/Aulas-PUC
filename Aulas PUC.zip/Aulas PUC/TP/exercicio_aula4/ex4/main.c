#include <stdio.h>
#include "A.h"

int main(){
    int base, exp;
    scanf("%d", &base);
    scanf("%d", &exp);
    printf("%d\n", pot(base, exp));
    return 0;
}