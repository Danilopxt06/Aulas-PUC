#include <stdio.h>
#include "A.h"

int main(){
    int n;
    scanf("%d", &n);
    printf("%d", pot(n));
    return 0;
}