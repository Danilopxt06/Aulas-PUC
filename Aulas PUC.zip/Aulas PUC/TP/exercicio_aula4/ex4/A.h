#ifndef A_H
#define A_H

int pot(int n);

#endif