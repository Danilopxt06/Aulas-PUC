#ifndef A_H
#define A_H

int cont(int n);

#endif