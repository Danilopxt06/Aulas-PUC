#include <stdio.h>
#include "A.h"

int main(){
    int n, i;
    scanf("%d", &n);
    for (i = 0; i < n; i++){
        printf("%d\n", cont(n));
    }
    return 0;
}