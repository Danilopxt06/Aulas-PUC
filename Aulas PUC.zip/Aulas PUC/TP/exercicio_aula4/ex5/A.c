#include "A.h"
#include <stdio.h>

int cont(int n){
    if (n==0){
        return 0;
    }
    printf("%d\n", n);
    return n = cont(n-1);
}