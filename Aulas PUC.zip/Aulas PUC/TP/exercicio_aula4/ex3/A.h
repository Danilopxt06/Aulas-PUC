#ifndef A_H
#define A_H

int soma(int n);

#endif