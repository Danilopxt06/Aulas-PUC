#include "A.h"

int soma(int n){
    if (n<=1){
        return n;
    }
    return n + soma(n - 1);
}