/*
EX03 – Criar uma função recursiva soma(int n) que calcule a soma de 1 até n.
*/
#include <stdio.h>
#include "A.h"

int main(){
    int n;
    scanf("%d", &n);
    printf("%d", soma(n));
    return 0;
}