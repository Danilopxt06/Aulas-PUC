//EX01 – Criar um módulo recursivo contendo a função fatorial(int n). Separar em main.c,
//recursao.c e recursao.h.
#include <stdio.h>
#include "REC.h"

int main(){
    int n;
    scanf("%d", &n);
    printf("%d", fatorial(n));
    return 0;
}
