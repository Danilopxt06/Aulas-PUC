#ifndef REC_H
#define REC_H

int fatorial(int n);

#endif