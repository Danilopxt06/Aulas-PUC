#include <stdio.h>
#include "A.h"

int main(){
    int a, b, m, i;
    scanf("%d", &a);
    scanf("%d", &b);
    printf("%d\n", mult(a, b));
    return 0;
}