#include "A.h"
#include <stdio.h>

int mult(int a, int b){
    if (b==0){
        return 0;
    }
    else if (b==1){
        return a;
    }
    return a + mult(a, b-1);
}