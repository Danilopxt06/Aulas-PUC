#ifndef A_H
#define A_H

int mult(int a, int b);

#endif