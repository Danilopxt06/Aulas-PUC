#include  <stdio.h>
int main(){
    //revisão de C
    int d, h, m, s, st;
    scanf("%d", &d);
    scanf("%d", &h);
    scanf("%d", &m);
    scanf("%d", &s);

    st = (d * 86400) + (h * 3600) + (m * 60) + s;

    printf("total de segundos: %d\n", st);
    return 0;
}