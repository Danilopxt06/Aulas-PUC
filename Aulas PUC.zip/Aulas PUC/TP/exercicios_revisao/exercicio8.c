#include <stdio.h>

//Teste de função
int main(){
    float t1;
    float t2;
    printf("Digite a temperatura em celcius: ");
    scanf("%f", &t2);
    t1 = (t1 - 32) * 1.8;
    printf("A temperatua em Fahrenheit: %.1f F\n", t2);
    return 0;
}