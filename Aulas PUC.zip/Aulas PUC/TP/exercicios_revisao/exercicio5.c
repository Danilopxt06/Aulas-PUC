#include  <stdio.h>
int main(){
    //revisão de C
    float val, p, total, desc;
    scanf("%f", &val);
    scanf("%f", &p);
    p = p * 0.01;
    desc = val * p;
    total = val - desc;
    printf("valor do desconto: %.1f\n", desc);
    printf("valor total: %.1f\n", total);

    return 0;
}