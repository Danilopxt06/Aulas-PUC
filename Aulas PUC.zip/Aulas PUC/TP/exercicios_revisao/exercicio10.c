#include <stdio.h>
int main(){
    float qtd, a, min, d;
    printf("Insira a quatidade de cigarros fumados por dia: ");
    scanf("%f", &qtd);
    printf("Há quantos você fuma? ");
    scanf("%f", &a);
    
    min = qtd * 10;
    d = min / 1440;
    a = a * 365;
    d = d * a;

    printf("%.2f dias", d);
    return 0;
}