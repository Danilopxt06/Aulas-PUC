#include <stdio.h>
int main(){
    float m[3][3], k;
    int i, j;
    
    for (i = 0; i < 3; i++){
        for (j = 0; j < 3; j++){
            scanf("%f", &m[i][j]);
        }  
    }

    scanf("%f", &k);

    for (i = 0; i < 3; i++){
        for (j = 0; j < 3; j++){
            if(m[i][j] == k){
                printf("O numero foi encontrado em m[%d][%d]", i, j);
            }
            else{
                printf("Chave não encontrada");
            }
        }  
    }

    
    return 0;
}