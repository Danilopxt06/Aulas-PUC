#include  <stdio.h>
int main(){
    //revisão de C
    float m, mm;
    scanf("%f", &m);
    mm = m * 1000;
    printf("%.2f\n", mm);
    return 0;
}