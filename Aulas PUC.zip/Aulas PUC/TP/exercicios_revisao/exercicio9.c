#include <stdio.h>
int main(){
    float km, total;
    int d;
    printf("insira a quatidade de Quilômetros: ");
    scanf("%f", &km);
    printf("insira a quatidade de dias: ");
    scanf("%d", &d);
    total = (d*60) + (km * 0.15);
    printf("R$ %.2f\n", total);
    return 0;
}