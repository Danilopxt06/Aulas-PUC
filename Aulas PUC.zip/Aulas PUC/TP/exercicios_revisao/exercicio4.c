#include  <stdio.h>
int main(){
    //revisão de C
    float sal, p, aum;
    scanf("%f", &sal);
    scanf("%f", &p);
    p = p * 0.01;
    aum = sal * p;
    sal = sal + aum;
    printf("valor aumento: %.1f\n", aum);
    printf("valor do salário aumentado: %.1f\n", sal);

    return 0;
}