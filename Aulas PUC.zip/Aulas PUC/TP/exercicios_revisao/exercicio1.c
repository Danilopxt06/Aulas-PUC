#include  <stdio.h>
int main(){
    //revisão de C
    int a, b, x;
    scanf("%d", &a);
    printf("Primeiro numero %d\n", a);
    scanf("%d", &b);
    printf("Segundo numero %d\n", b);
    x = a + b;
    printf("A soma de A e B: %d\n", x);
    return 0;
}