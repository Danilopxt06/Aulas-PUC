#include <stdio.h>

//Teste de função
int main(){
    char nomes[5][100];
    int i, j;
    for (i = 0; i < 5; i++)
    {
        scanf("%s", nomes[i]);
    }

    for (i = 5; i > 0; i--)
    {
        printf("%s\n", nomes[i]);
    }

    return 0;
}