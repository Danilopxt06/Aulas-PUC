#include  <stdio.h>
int main(){
    //revisão de C
    int t, d, vm;
    scanf("%d", &d);
    scanf("%d", &vm);
    t = d * vm;
    printf("%d\n", t);

    return 0;
}