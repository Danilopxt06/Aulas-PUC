#include "A.h"
#include <stdio.h>

int somar(int *p){
    int i, soma=0;
    for (i = 0; i < 5; i++){
        scanf("%d", p+i);
        soma = soma + *(p+i); 
    }
    return soma;
}