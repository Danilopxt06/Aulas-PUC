#ifndef A_H
#define A_H

    int somar(int *p);

#endif