#include <stdio.h>

int main(){
    int v[5];
    printf("%d", somar(v));
    return 0;
}