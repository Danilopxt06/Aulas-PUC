#ifndef A_H
#define A_H

int maisum(int *p, int n);


#endif