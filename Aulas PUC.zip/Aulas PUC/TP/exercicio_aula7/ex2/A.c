#include "A.h"

int maisum(int *p, int n){
    *p = *p + n;
    return *p;
}