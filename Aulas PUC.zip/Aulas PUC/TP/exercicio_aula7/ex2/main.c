#include <stdio.h>
#include "A.h"

int main(){
    int x = 10;
    int *p = &x;
    int n;
    scanf("%d", &n);
    maisum(p, n);
    printf("%d", x);
    return 0;
}