#include <stdio.h>

int main(){
    int v[5], i;
    dobrar(v);
    for (i = 0; i < 5; i++){
        printf("%d", v[i]);
    }
    
    
    return 0;
}