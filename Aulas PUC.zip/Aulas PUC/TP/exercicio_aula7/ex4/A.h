#ifndef A_H
#define A_H

int dobra(int *p);


#endif