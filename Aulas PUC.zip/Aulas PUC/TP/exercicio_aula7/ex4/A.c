#include "A.h"
#include <stdio.h>

int dobrar(int *p){
    int i;
    for (i = 0; i < 5; i++){
        scanf("%d", p+i);
        *(p+i) = *(p+i) * 2; 
    }
    
}