#include <stdio.h>

int main(){
    int temp = 0, a, b;
    a = 10;
    b = 12;
    int *p1 = &a, *p2 = &b;
    printf("%d | %d\n", *p1, *p2);
    temp = *p1;
    *p1 = *p2;
    *p2 = temp;
    printf("%d | %d\n", *p1, *p2);
    return 0;
}