#include <stdio.h>
int main(){
    int i, j, m[2][2];
    int soma=0;
    for (i = 0; i < 2; i++){
        for (j = 0; j < 2; j++){
            scanf("%d", &m[i][j]);
        }
    }

    for (i = 0; i < 2; i++){
        for (j = 0; j < 2; j++){
            soma = soma + m[i][j];
        }
    }

    printf("soma = %d\n", soma);

    
}