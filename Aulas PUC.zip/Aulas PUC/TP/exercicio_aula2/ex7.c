#include <stdio.h>
int main(){
    int i, j, m[3][3];
    int maior=0, menor=10000;
    for (i = 0; i < 3; i++){
        for (j = 0; j < 3; j++){
            scanf("%d", &m[i][j]);
        }
    }

    for (i = 0; i < 3; i++){
        for (j = 0; j < 3; j++){
            if (m[i][j]>maior){
                maior=m[i][j];
            }
            else if(m[i][j]<menor){
                menor=m[i][j];
            }  
        }
    }

    printf("menor = %d\n", maior);
    printf("menor = %d\n", menor);

    
}