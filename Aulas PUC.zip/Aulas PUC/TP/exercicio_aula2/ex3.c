#include <stdio.h>
int main(){
    int i, j, m[3][3];
    int par=0;

    for (i = 0; i < 3; i++){
        for (j = 0; j < 3; j++){
            scanf("%d", &m[i][j]);
        }
    }

    for (i = 0; i < 3; i++){
        for (j = 0; j < 3; j++){
            if (m[i][j] %2 == 0){
                par = par + 1;
            }        
        }
    }

    printf("Existem %d Numeros Pares", par);
    
}