#include <stdio.h>
int main(){
    int i, j, m[3][3];
    for (i = 0; i < 3; i++){
        for (j = 0; j < 3; j++){
            if (j==i){
                m[i][j]=1;
            }
            else{
                m[i][j]=0;
            }
        }
    }
    for (i = 0; i < 3; i++){
        for (j = 0; j < 3; j++){
            printf("%d", m[i][j]);
        }
        printf("\n");
    }
}