#include <stdio.h>
int main(){
    int i, j, m[2][3];
    int soma=0, media=0;
    for (i = 0; i < 2; i++){
        for (j = 0; j < 3; j++){
            scanf("%d", &m[i][j]);
        }
    }

    for (i = 0; i < 2; i++){
        for (j = 0; j < 3; j++){
            soma = soma + m[i][j];
        }
    }
    
    media = soma/6;

    printf("soma = %d\n", soma);
    printf("media = %d\n", media);
    
}