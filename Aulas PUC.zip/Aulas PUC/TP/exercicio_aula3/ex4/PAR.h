#ifndef PAR_H
#define PAR_H

int par(int a);

#endif