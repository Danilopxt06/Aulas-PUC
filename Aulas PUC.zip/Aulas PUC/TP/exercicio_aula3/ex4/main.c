/*
Criar uma função ehPar(int n) 
que retorne 1 se for par e 0 caso contrário.
*/
#include <stdio.h>
#include "PAR.h"

int main(){
    int a;
    scanf("%d", &a);
    printf("%d", par(a));
    return 0;
}