#include "PAR.h"

int par(int a){
    if(a%2==0){
        printf("EhPar");
    }
    else{
        printf("Impar");
    }
}