#include "MT.h"

float soma(float a, float b){
    return a+b;
}
float sub(float a, float b){
    return a-b;
}