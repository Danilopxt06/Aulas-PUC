#include <stdio.h>
#include "MT.h"

int main(){
    float a,b;
    scanf("%f", &a);
    scanf("%f", &b);
    printf("soma = %.1f\n", soma(a,b));
    printf("subtracao = %.1f\n", sub(a,b));
    return 0;
}