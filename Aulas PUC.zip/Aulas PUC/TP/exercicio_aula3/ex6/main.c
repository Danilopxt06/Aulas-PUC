#include <stdio.h>
#include "M.h"

int main(){
    float n1, n2, m;
    scanf("%f", &n1);
    scanf("%f", &n2);

    m = calcula(n1, n2);
    imprime(m);
    
    return 0;
}