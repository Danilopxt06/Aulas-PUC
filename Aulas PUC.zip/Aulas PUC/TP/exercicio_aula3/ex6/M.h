#ifndef M_H
#define M_H

float calcula(float n1, float n2);
float imprime(float m);

#endif