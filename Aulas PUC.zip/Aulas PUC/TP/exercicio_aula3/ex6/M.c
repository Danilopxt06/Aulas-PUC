#include "M.h"
#include <stdio.h>

float calcula(float n1, float n2){
    return (n1*0.4) + (n2*0.6);
}

float imprime(float m){
    printf("%.1f\n", m);
    if(m>=6.0){
        printf("APROVADO!\n");
    }
    else{
        printf("REPROVADO!\n");
    }
}