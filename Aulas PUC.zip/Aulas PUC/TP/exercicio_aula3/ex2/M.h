#ifndef M_H
#define M_H

float media(float a, float b);

#endif