#include <stdio.h>
#include "M.h"

int main(){
    float a,b;
    scanf("%f", &a);
    scanf("%f", &b);
    printf("%.1f", media(a,b));
    return 0;
}