#include "M.h"

float media(float a, float b){
    return (a+b)/2;
}