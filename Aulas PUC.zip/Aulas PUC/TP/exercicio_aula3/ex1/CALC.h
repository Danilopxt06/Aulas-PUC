#ifndef CALC_H
#define CALC_H

int dobro(int a);

#endif
