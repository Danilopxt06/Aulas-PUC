#include <stdio.h>
#include "CALC.h"

int main(){
    int n;
    scanf("%d", &n);
    printf("%d", dobro(n));
    return 0;
}