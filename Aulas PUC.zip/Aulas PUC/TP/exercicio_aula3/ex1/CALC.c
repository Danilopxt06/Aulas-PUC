#include "CALC.h"

int dobro(int a){
    return a*2;
}