#ifndef M_H
#define M_H

void imprime(int m[2][2]);

#endif