#include "M.h"
#include <stdio.h>

void imprime(int m[2][2]){
    for (int i = 0; i < 2; i++){
        for (int j = 0; j < 2; j++){
            scanf("%d", &m[i][j]);
        }
    }

    for (int i = 0; i < 2; i++){
        for (int j = 0; j < 2; j++){
            printf("%d ", m[i][j]);
        }
        printf("\n");
    }
    
}

