#include <stdio.h>
#include "M.h"

int main(){
    int m[2][2];
    imprime(m);
    return 0;
}