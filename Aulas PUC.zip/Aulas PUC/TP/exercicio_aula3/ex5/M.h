#ifndef M_H
#define M_H

float media(float n1, float n2, float m);

#endif