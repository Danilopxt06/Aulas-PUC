#include "M.h"
#include <stdio.h>

float media(float n1, float n2, float m){
    m = (n1*0.4) + (n2*0.6);
    printf("%.1f\n", m);
    if(m>=6.0){
        printf("APROVADO!\n");
    }
    else{
        printf("REPROVADO!\n");
    }
}