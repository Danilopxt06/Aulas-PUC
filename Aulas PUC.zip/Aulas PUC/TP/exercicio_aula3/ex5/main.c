#include <stdio.h>
#include "M.h"

int main(){
    float n1, n2;
    scanf("%f", &n1);
    scanf("%f", &n2);
    media(n1, n2, 0);
    return 0;
}