#include <stdio.h>
int main(){
    int n1, n2, sm, sb, m;
    scanf("%d", &n1);
    scanf("%d", &n2);
    sm = n1+n2;
    sb = n1-n2;
    m = n1*n2;
    printf("%d\n%d\n%d\n", sm, sb, m);
    return 0;
}