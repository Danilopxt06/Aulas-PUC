#include <stdio.h>
int main(){
    char nome [20];
    int idade;
    scanf("%s", &nome);
    scanf("%d", &idade);
    printf("Ola %s, voce tem %d anos!", nome, idade);
    return 0;
}