#include <stdio.h>
int main(){
    int n, d;
    scanf("%d", &n);
    d = n*2;
    printf("%d", d);
    return 0;
}