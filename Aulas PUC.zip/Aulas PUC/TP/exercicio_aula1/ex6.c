#include <stdio.h>
int main(){
    char caracter;
    scanf("%c", &caracter);
    printf("o caracter %c eh %d na tabela ascii", caracter, caracter);
    return 0;
}