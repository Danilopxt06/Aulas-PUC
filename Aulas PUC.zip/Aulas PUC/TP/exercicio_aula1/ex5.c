#include <stdio.h>
int main(){
    int n1, n2, r;
    scanf("%d", &n1);
    scanf("%d", &n2);
    r = n1%n2;
    printf("%d", r);
    return 0;
}