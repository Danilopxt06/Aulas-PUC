#include <stdio.h>
int main(){
    float n1, n2, sm;
    scanf("%f", &n1);
    scanf("%f", &n2);
    sm = n1+n2;
    sm = sm * 3;
    printf("%.2f\n", sm);
    return 0;
}