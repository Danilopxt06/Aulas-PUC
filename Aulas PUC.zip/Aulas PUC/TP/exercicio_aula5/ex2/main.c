#include <stdio.h>

void statica(){
    static int x = 0;
    int y = 0;

    x = x + 1;
    y = y + 1;

    printf("STATIC = %d | COMUM = %d\n", x, y);
}

int main(){
    int i;
    for (i = 0; i < 5; i++)
    {
        statica();
    }

    return 0;
}