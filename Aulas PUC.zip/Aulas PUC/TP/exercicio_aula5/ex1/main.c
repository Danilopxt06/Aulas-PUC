#include <stdio.h>

int x = 5;

void teste(){
    int x = 10;
    printf("%d\n", x);
}

int main(){
    teste();
    printf("%d\n", x);
    return 0;
}

/*
A conteúdo imprimido na função teste é advindo de uma variável local, já o que está sendo chamado na
função main.c pertence à variável global
*/