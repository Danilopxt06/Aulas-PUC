/*
EX03 – Desenvolva um programa com variável global modificada por duas funções distintas
(incremento e decremento). Determine o valor final.
*/
#include <stdio.h>
int x = 100;

void inc(int n){
    x = x+n;
}

void dec(int n){
    x = x-n;
}

int main(){
    int n;
    scanf("%d", &n);
    inc(n);
    printf("%d\n", x);
    dec(n);
    printf("%d\n", x);
    
    return 0;
}