#include <stdio.h>
void quad(int *n){
    *n = *n * *n;
}

int main(){
    int n;
    scanf("%d", &n);
    quad(&n);
    printf("%d", n);
}