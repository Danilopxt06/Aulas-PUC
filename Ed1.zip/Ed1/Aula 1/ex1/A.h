#ifndef A_H
#define A_H

void push(int num, int *pilha, int tam);
void pop(int *pilha, int tam);

#endif
