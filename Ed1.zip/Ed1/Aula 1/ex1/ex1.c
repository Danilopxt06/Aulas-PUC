#include <stdio.h>
#include "A.h"

int num;
int tam;
int topo = -1;
int pilha[tam];

int push(int num, int *pilha, int tam){
    topo++;
    scanf("%d", &num);
    if (topo == tam){
        printf("Stack Overflow\n");
        return 0;
    }
    pilha[topo] = num;
}

int pop(int *pilha, int tam){
    num = pilha[topo];
    topo--;
    return num;
}


int main (){
    int opcao;
    int num;

    do{
        printf("Escolha uma opção:\n");
        printf("1 - Empilhar\n");
        printf("2 - Desempilhar\n");
        printf("0 - Sair\n");
        scanf("%d", &opcao);
        
        switch (opcao){
            case 1:
                push(num, pilha, tam);
                break;
            case 2:
                pop(pilha, tam);
                break;
            case 0:
                printf("Programa encerrado!\n");
                break;
            default:
                printf("Opção Invalida!\n");
                break;
        }
    } while(opcao != 0);
    return 0;
}