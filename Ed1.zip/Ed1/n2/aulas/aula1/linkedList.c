#include <stdio.h>
#include <stdlib.h>

// Definição da estrutura do nó da lista
typedef struct No {
    int dado;
    struct No* prox;
} No;

// Função para inserir um elemento no início da lista
void push_inicio(No** l, int valor) {
    No* novo = (No*)malloc(sizeof(No));
    if (novo == NULL) {
        printf("Erro ao alocar memoria!\n");
        return;
    }
    novo->dado = valor;
    novo->prox = *l;
    *l = novo;
}

// Função para inserir um elemento no fim da lista
void push_fim(No** l, int valor) {
    No* novo = (No*)malloc(sizeof(No));
    if (novo == NULL) {
        printf("Erro ao alocar memoria!\n");
        return;
    }
    novo->dado = valor;
    novo->prox = NULL;

    // Se a lista estiver vazia, o novo nó se torna a cabeça
    if (*l == NULL) {
        *l = novo;
        return;
    }

    // Caso contrário, percorre até o último nó
    No* atual = *l;
    while (atual->prox != NULL) {
        atual = atual->prox;
    }
    atual->prox = novo;
}

// Função pop para remover do fim da lista
void pop_fim(No** l) {
    // 1. Verifica se a lista está vazia
    if (*l == NULL) {
        puts("A Lista está vazia!");
        return;
    }

    // 2. Se houver apenas 1 elemento na lista
    if ((*l)->prox == NULL) {
        No* temp = *l;
        *l = NULL; // A lista fica vazia
        printf("Elemento removido do fim: %d\n", temp->dado);
        free(temp);
        return;
    }

    // 3. Percorre até encontrar o penúltimo nó
    No* atual = *l;
    while (atual->prox->prox != NULL) {
        atual = atual->prox;
    }

    // 'atual' é o penúltimo, e 'atual->prox' é o último
    No* temp = atual->prox;
    
    // O penúltimo agora passa a ser o último (aponta para NULL)
    atual->prox = NULL;

    printf("Elemento removido do fim: %d\n", temp->dado);

    // Libera a memória do último nó
    free(temp);
}

// Função auxiliar para imprimir a lista
void imprimir_lista(No* l) {
    No* atual = l;
    printf("Lista: ");
    while (atual != NULL) {
        printf("%d -> ", atual->dado);
        atual = atual->prox;
    }
    printf("NULL\n");
}

int main() {
    No* l = NULL;

    // Inserindo elementos
    push_fim(&l, 10);
    push_fim(&l, 20);
    push_fim(&l, 30);

    imprimir_lista(l); // Lista: 10 -> 20 -> 30 -> NULL

    // Testando o pop do fim
    pop_fim(&l);       // Deve remover o 30
    imprimir_lista(l); // Lista: 10 -> 20 -> NULL

    return 0;
}