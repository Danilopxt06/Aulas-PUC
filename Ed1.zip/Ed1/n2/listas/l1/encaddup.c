#include <stdio.h>
#include <stdlib.h>

#define Tipo int

typedef struct no{
    Tipo valor;
    struct no * proximo;
    struct no * anterior;
}No;

No* criarNo(Tipo novo){
    //Criar um elemento para Lista Duplamente Ligada no Heap
    No* n = (No*) malloc(sizeof(No));
    //Atribuir os valores às variáveis que compõem o elemento criado
    n->anterior = NULL;
    n->proximo = NULL;
    n->valor = novo;
    //retornar o endereço do elemento criado para quem chamou a função
    return n;
}

typedef struct listadupligada{
    No* inicio;
    No* fim;
    int qtde;
}ListDupLigada;

ListDupLigada* criarListaDupLigada(){
    //Criar uma Lista Duplamente Ligada no Heap
    ListDupLigada* l = (ListDupLigada*)malloc(sizeof(ListDupLigada));
    //Atribuir valores às variáveis que compõem a lista duplamente ligada
    l->fim = NULL;
    l->inicio = NULL;
    l->qtde = 0;
    //retornar o endereço da lista duplamente ligada à quem chamou a função
    return l;
}

void push_inicio(ListDupLigada* l, No* n){
    //Cenário - Lista ou Elemento não existentes
    if(l == NULL || n == NULL){
        puts("Lista ou Elemento nulos");
    }
    else{
        //Cenário - Lista Vazia
        if(l->qtde==0){
            l->inicio = n;
            l->fim = n;
        }
        //Cenário - Lista com um ou mais elementos
        else{
            //Primeiro - Ligar o novo elemento no início da lista
            n->proximo = l->inicio;
            //Segundo - Ligar o inicio da lista no novo elemento
            //        - Ligar a lista no novo elmento
            l->inicio->anterior = n;
            //Terceiro - Transferir o início da lista para o novo elemento
            l->inicio = n;
        }
        //Incrementar a quantidade de elementos da lista
        l->qtde++;
    }
}

No* pop_inicio(ListDupLigada* l){
    No* aux = NULL;
    //Cenário - Lista não existente
    if(l == NULL){
        puts("Lista inexistente");
    }
    //Cenário de lista existente
    else{
        //Cenário - Lista vazia
        if(l->qtde == 0){
            puts("Lista Vazia");
        }
        //Cenário - Lista com elementos
        else{
            aux = l->inicio;
            //Cenário - Lista com apenas um elemento
            if(l->qtde == 1){
                l->inicio = NULL;
                l->fim = NULL;
            }
            //Cenário - Lista com mais de um elemento
            else{
                //Atualizar o inicio para o segundo elemento
                l->inicio = l->inicio->proximo;
                //Desligar o segundo elemento do inicio da lista (aux)
                l->inicio->anterior = NULL;
                //Desligar o antigo inicio (aux) da lista
                aux->proximo = NULL;
            }
            //Decrementar a quantidade de elementos da lista
            l->qtde--;
        }
    }
    //Retornar o inicio da lista(aux) para quem chamou a função
    return aux;
}

void push_fim(ListDupLigada *l, No* n){
    //Cenário - Lista não existente
    if(l == NULL || n == NULL){
        puts("Lista ou Elemento inexistentes");
    }
    //Cenário de lista e elemento existentes
    else{
        //Cenário - Lista vazia
        if(l->qtde == 0){
            l->inicio = n;
            l->fim = n;
        }
        //Cenário - Lista com elemento
        else{
            //Ligar o novo elemento na lista
            n->anterior = l->fim;
            //Ligar o a lista (fim) no novo elemento
            l->fim->proximo = n;
        }
        l->qtde++;
    }
}

No* pop_fim(ListDupLigada* l){
    No* aux = NULL;
    //Cenário - Lista não existente
    if(l == NULL){
        puts("Lista inexistente");
    }
    //Cenário de lista existente
    else{
        //Cenário - Lista vazia
        if(l->qtde == 0){
            puts("Lista vazia");
        }
        //Cenário - Lista com elemento
        else{
            aux = l->fim;
            //Cenário - Lista com elemento único
            if(l->qtde == 1){
                l->fim = NULL;
                l->inicio = NULL;
            }
            //Cenário - Lista com mais de um elemento
            else{
                //Atualizar o fim da lista para o penúltimo elemento
                l->fim = l->fim->anterior;
                //Desligar a lista do último elemento do aux (antigo fim)
                l->fim->proximo = NULL;
                //Desligar o aux da lista
                aux->anterior = NULL;
            }
            l->qtde--;
        }
    }
    return aux;
}

/*
1. Função para buscar um elemento (int) e retornar sua posição na sequência da lista ligada. Caso o elemento não esteja na lista, retorne um número negativo.
2. Função para retirar um elemento de uma posição, que será passada como parâmetro. Esta função deve validar a posição, caso a posição não seja válida (posição negativa, ou que ultrapasse o tamanho da lista).
3. Função para inserir um elemento de uma posição, que será passada como parâmetro. Esta função deve validar a posição, caso a posição não seja válida (posição negativa, ou que esteja fora do escopo da lista).
4. Função que ordene a lista, utilizando o algoritmo Insertion-Sort.  
*/