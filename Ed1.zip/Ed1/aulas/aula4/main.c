#include <stdio.h>

#define TAM 10

int inicio = 0;
int fim = 0;

int filadaputa[TAM];

int fila(int num) {

    filadaputa[fim] = num;
    fim++;

    return 1;
}

int desfila() {

    int valor = filadaputa[inicio];
    inicio++;

    return valor;
}

int main() {
    int num;

    scanf("%d", &num);

    fila(num);

    printf("%d\n", desfila());

    return 0;
}
