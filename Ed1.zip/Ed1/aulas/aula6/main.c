#include <stdio.h>
#include <stdlib.h>

int merge (int *A, int p, int q, int r){

}

int main() {
    int i, j, k, tmp;
    h = i = j = 0;
    int A1[4] = {1,3,7,9};
    int A2[4] = {0,2,5,6};
    int A[8];
    while (h<8){
        if(A1[i]<A2[j]){
            A[h] = A1[i];
            i++;
        }
        else{
            A[h] = A2[j];
            j++
        }
        h++;
    }
    return 0;
}