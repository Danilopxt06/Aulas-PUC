#include <stdio.h>
#include <stdlib.h>

void trocar(){
    
}

int main() {

    return 0;
}