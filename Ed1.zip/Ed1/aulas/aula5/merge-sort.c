#include <stdio.h>
#include <stdlib.h>

void mergeSort(int vetor[], int inicio, int fim);
void merge(int vetor[], int inicio, int meio, int fim);
void printVetor(int vetor[], int tamanho);

void merge(int vetor[], int inicio, int meio, int fim){
    int tamanhoEsq = meio - inicio + 1;
    int tamanhoDir = fim - meio;

    int *esquerda = (int *)malloc(tamanhoEsq * sizeof(int));
    int *direita = (int *)malloc(tamanhoDir * sizeof(int));
    
    int i, j, k;

    // Copiando dados para os subarrays temporários
    for (i = 0; i < tamanhoEsq; i++){
        esquerda[i] = vetor[inicio + i];
    }
    for (j = 0; j < tamanhoDir; j++){
        direita[j] = vetor[meio + 1 + j]; // Corrigido: usa j e começa de meio + 1
    }

    // Mesclando os subarrays de volta no vetor original
    i = 0;
    j = 0;
    k = inicio;
    
    while (i < tamanhoEsq && j < tamanhoDir) {
        if (esquerda[i] <= direita[j]) {
            vetor[k++] = esquerda[i++];
        } else {
            vetor[k++] = direita[j++];
        }
    }

    // Copiando os elementos restantes de esquerda[], se houver
    while (i < tamanhoEsq) {
        vetor[k++] = esquerda[i++];
    }

    // Copiando os elementos restantes de direita[], se houver
    while (j < tamanhoDir) {
        vetor[k++] = direita[j++];
    }

    // Liberando a memória alocada dinamicamente
    free(esquerda);
    free(direita);
}

void mergeSort(int vetor[], int inicio, int fim) {
    if (inicio < fim) {
        int meio = inicio + (fim - inicio) / 2;

        // Ordena a primeira e a segunda metade
        mergeSort(vetor, inicio, meio);
        mergeSort(vetor, meio + 1, fim);

        // Mescla as metades ordenadas
        merge(vetor, inicio, meio, fim);
    }
}

void printVetor(int vetor[], int tamanho) {
    for (int i = 0; i < tamanho; i++) {
        printf("%d ", vetor[i]);
    }
    printf("\n");
}

int main() {
    int vetor[] = {38, 27, 43, 3, 9, 82, 10};
    int tamanho = sizeof(vetor) / sizeof(vetor[0]);

    printf("Vetor original:\n");
    printVetor(vetor, tamanho);

    mergeSort(vetor, 0, tamanho - 1);

    printf("Vetor ordenado:\n");
    printVetor(vetor, tamanho);

    return 0;
}