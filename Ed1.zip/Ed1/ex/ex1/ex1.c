#include <stdio.h>

#define MAX 100

int pilha[MAX];
int topo = -1;

void converte(int num) {
    int tmp;

    if (topo == MAX - 1) {
        printf("Pilha cheia!\n");
        return;
    }

    while (num != 0) {
        tmp = num % 2;
        num = num / 2;

        topo++;
        pilha[topo] = tmp;
    }

    while (topo != -1) {
        int num = pilha[topo];
        topo--;

        printf("%d", num);
    }

    printf("\n");
}

int main() {
    int num;

    scanf("%d", &num);

    converte(num);

    return 0;
}
