#include <stdio.h>
#include "A.h"

#define TAM 5

int num;
int topo = -1;
int pilha[TAM];

void push(int num, int *pilha, int tam)
{

    if (topo == tam - 1)
    {
        printf("Stack Overflow\n");
        return;
    }
    scanf("%d", &num);
    topo++;
    pilha[topo] = num;
}

void pop(int *pilha, int tam)
{
    printf("Numero desempilhado: %d\n", pilha[topo]);
    topo--;
}

int main()
{
    int opcao;
    do
    {
        printf("\nEscolha uma opcao:\n");
        printf("1 - Empilhar\n");
        printf("2 - Desempilhar\n");
        printf("0 - Sair\n");
        scanf("%d", &opcao);
        switch (opcao)
        {
        case 1:
            push(num, pilha, TAM);
            break;
        case 2:
            pop(pilha, TAM);
            break;
        case 0:
            printf("Programa encerrado!\n");
            break;
        default:
            printf("Opcao Invalida!\n");
            break;
        }
    } while (opcao != 0);
    return 0;
}