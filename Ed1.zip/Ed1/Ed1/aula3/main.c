#include <stdio.h>
#include <stdlib.h>
#include "pilha.h"

int main(){
    Pilha *p = criarPilha(4);
    int num, op = menuPilha();

    while(op != 0){
        switch(op)
        {
            case 1:
                puts("Digite o número a ser Empilhado:");
                scanf("%d", &num);
                push(p, num);
                break;
            case 2:
                pop(p);
                break;
        }
        op = menuPilha();
    }
    free(p->pilha);
    free(p);

    return 0;
}
