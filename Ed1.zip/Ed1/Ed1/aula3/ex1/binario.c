//Usar módulo para ir tirando o resto e ir empilhando
//Na hora de desempilhar o número sai correto pois a conta dá o número de trás pra frente

