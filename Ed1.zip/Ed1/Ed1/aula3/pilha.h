#include <stdio.h>
#include <stdlib.h>

#define TIPO int

typedef struct{
    TIPO *pilha;
    int topo;
    int qtd;
    int tamanho;
} Pilha;

Pilha *criarPilha(int tamanho){
    Pilha *p = malloc(sizeof(Pilha));

    p->tamanho = tamanho;
    p->topo = -1;
    p->qtd = 0;
    p->pilha = malloc(tamanho * sizeof(TIPO));

    return p;
}

void push(Pilha *p, TIPO novo){
    if(p != NULL){
        if(p->qtd >= p->tamanho){
            puts("Stack overflow");
        }
        else{
            p->topo++;

            // Aritmética de ponteiro explícita
            *((p->pilha) + p->topo) = novo;

            p->qtd++;
        }
    }
    else{
        puts("Pilha inexistente");
    }
}

void pop(Pilha *p){
    TIPO n;

    if(p == NULL){
        puts("Pilha inexistente");
    }
    else if(p->qtd == 0){
        puts("Pilha vazia");
    }
    else{
        // Aritmética de ponteiro explícita
        n = *((p->pilha) + p->topo);

        p->topo--;
        p->qtd--;

        printf("Elemento desempilhado: %d\n", n);
    }
}

int menuPilha(){
    puts("1 - Empilhar");
    puts("2 - Desempilhar");
    puts("3 - Sair");

    int op;
    scanf("%d", &op);

    return op;
}
