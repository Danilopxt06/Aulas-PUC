#include <stdio.h>
#include <stdlib.h>

void mergeSort(int vetor[], int inicio, int fim);
void merge(int vetor[], int inicio, int meio, int fim);
void printVetor(int vetor[], int tamanho);

void merge(int vetor[], int inicio, int meio, int fim){
    int tamanhoEsq = meio - inicio + 1;
    int tamanhoDir = fim - meio;

    int *esquerda = (int *)malloc(tamanhoEsq * sizeof(int));
    int *direita = (int *)malloc(tamanhoDir * sizeof(int));
    
    int i, j, k;

    for (i = 0; i < tamanhoEsq; i++){
        esquerda[i] = vetor[inicio + i];
    }
    for (j = 0; j < tamanhoDir; j++){
        direita[i] = vetor[meio + i + j];
    }
    i = 0;
    j = 0;
    k = inicio;
    
}





int main(){
    return 0;
}