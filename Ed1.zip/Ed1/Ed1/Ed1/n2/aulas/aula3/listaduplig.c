#include <stdio.h>
#include <stdlib.h>

#define TIPO int
typedef struct no{
    TIPO valor;
    struct no * proximo;
    struct no * anterior;
}No;

No* criarNo(TIPO novo){
    //criar um novo elemento para lista duplamente ligada no Heap
    No* n = (No*) malloc(sizeof(No));

    //Atribuir os valores que compõe o elemento ligado
    n->anterior = NULL;
    n->proximo = NULL;
    n->valor = novo;

    //Retornando o endereço do elemento criado para quem chamou a função
    return n;
}

typedef struct listadup{
    No* inicio;
    No* fim;
    int qtd;
}ListaDup;

ListaDup* criarLista(){
    //Criar a lista duplamente ligada no Heap
    ListaDup* l = (ListaDup*) malloc(sizeof(ListaDup));
    //Atribuir valores às variáveis que compõe a lista duplamente encadeada
    l->inicio = NULL;
    l->fim = NULL;
    l->qtd = 0;
    return l;
}

void push_inicio(ListaDup* l, No* n){
    // Lista ou elemento não existentes
    if(l == NULL || n == NULL){
        puts("Lista ou elementos nulos\n");
    }
    else{
        //Lista vazia
        if(l->qtd == 0){
            l->inicio = n;
            l->fim = n;
        }
        //lista com 1 ou mais elementos
        else{
            //1º ligar o novo elemento no início da lista
            n->proximo = l->inicio;
            //2º ligar o início da lista no novo elemento
            //Ligar a lista no novo elemento
            l->inicio->anterior = n;
            //transferir o inicio da lista para o novo elemento
            l->inicio = n;
        }
        //incrementar a quantidade de elementos
        l->qtd++;
    }
}

No* pop_inicio(ListaDup* l){
    No* aux = NULL;
    // Lista ou elemento não existentes
    if(l == NULL){
        puts("Lista inexistente\n");
    }
    //lista existente
    else{
        //lista vazia
        if(l->qtd == 0){
            puts("lista vazia!\n");
        }
        //lista com elementos
        else{
            No* aux = l->inicio;
            //Lista com apenas 1 elemento
            if(l->qtd ==1){
                l->inicio = NULL;
                l->fim = NULL;
            }
            //Lista como mais de 1 elemento
            else{
                //desligar o segundo elemnto do inicio da lista
                l->inicio->proximo->anterior = NULL;
                //inicio passa a ser o segundo elemento
                l->inicio = l->inicio->proximo;
                //desligar o antigo inicio (aux) da lista
                aux->proximo = NULL;

            }
            //decrementar a quantidade de elemementos da lista
            l->qtd--;
        }
    }
    //
    return aux;
}