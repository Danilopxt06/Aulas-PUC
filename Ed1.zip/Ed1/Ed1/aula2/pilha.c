#include <stdio.h>
#include <stdlib.h>

#define TIPO int
#define MAX 4

typedef struct{
    TIPO *pilha;
    int tamanho;
    int topo;
    int qtd;
} Pilha;

Pilha * criarPilha(){
    Pilha *p;
    p = malloc(sizeof(Pilha));
    p -> pilha = malloc(MAX * sizeof(TIPO));
    p -> tamanho = MAX;
    p -> qtd = 0;
    p -> topo = -1;
    return p;
}

void push(Pilha *p, TIPO novo){
    if(p == NULL){
        puts("Pilha inexistente");
    }
    else{
        if (p->qtd == p->tamanho){
            puts("Stack Overflow\n");
        }
        else{
            p->topo++;
            *(p->pilha+p->topo) = novo;
        }
    }
}