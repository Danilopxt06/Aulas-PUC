#include <stdlib.h>
#include <stdio.h>
#define Tipo int

//Definição de um elemento dinâmico para lista ligada
typedef struct NO{
    Tipo conteudo;
    struct No* proximo;
}No;

//Definição Tipo Abstrato de Dados
typedef struct Lista{
    No* primeiro;
    Tipo qtd;
}Lista;

No* criarNo(Tipo n){
    No* novo = (No*) malloc(sizeof(No));
    novo->conteudo = n;
    novo->proximo = NULL;
    return novo;
}

Lista* criarLista(){
    Lista* l = (Lista*)malloc(sizeof(Lista));
    l->primeiro = NULL;
    l->qtd=0;
    return l;
}

//Operações da Lista

//INSERIR NO INICIO (PUSH INICIO)
void pushInicio (Lista* l, No* novo){
    if(l == NULL){
        puts("lista inexistente");
    }
    else if(novo == NULL){
        puts("Elemento inexistente");
    }
    else{
        novo->proximo = l->primeiro;
        l->primeiro = novo;
        l->qtd++;
    }
}

//RETIRAR NO INICIO (POP INICIO)
void popInicio(Lista* l, No* novo){
    
}


