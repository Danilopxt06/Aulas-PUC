#include <stdio.h>

#define MAX 100

int pilha[MAX];
int topo = -1;

void empilha(int i) {
    if (topo == MAX - 1) {
        puts("Pilha cheia!");
        return;
    }
    topo++;
    pilha[topo] = i;
}

int desempilha() {
    return pilha[topo--];
}

int pilhaVazia() {
    return topo == -1;
}

int topoPilha() {
    return pilha[topo];
}

int maior(int a, int b) {
    return a > b ? a : b;
}

// Para cada posicao, acha o indice da pessoa mais alta (ou igual) mais
// proxima a esquerda, usando uma pilha decrescente
void anteriorMaiorOuIgual(int arr[], int n, int resultado[]) {
    int i;

    topo = -1;

    for (i = 0; i < n; i++) {
        while (!pilhaVazia() && arr[topoPilha()] < arr[i]) {
            desempilha();
        }

        resultado[i] = pilhaVazia() ? -1 : topoPilha();

        empilha(i);
    }
}

// Mesma ideia, mas percorrendo da direita para a esquerda
void proximoMaiorOuIgual(int arr[], int n, int resultado[]) {
    int i;

    topo = -1;

    for (i = n - 1; i >= 0; i--) {
        while (!pilhaVazia() && arr[topoPilha()] < arr[i]) {
            desempilha();
        }

        resultado[i] = pilhaVazia() ? n : topoPilha();

        empilha(i);
    }
}

int maxPessoasVisiveis(int arr[], int n) {
    int esquerda[MAX], direita[MAX];
    int i, esq, dir, total, maiorTotal = 0;

    anteriorMaiorOuIgual(arr, n, esquerda);
    proximoMaiorOuIgual(arr, n, direita);

    for (i = 0; i < n; i++) {
        esq = i - esquerda[i] - 1;
        dir = direita[i] - i - 1;
        total = esq + dir + 1;

        maiorTotal = maior(maiorTotal, total);
    }

    return maiorTotal;
}

int main() {
    int arr[] = {6, 2, 5, 4, 5, 1, 6};
    int n = sizeof(arr) / sizeof(arr[0]);

    printf("Maximo de pessoas visiveis: %d\n", maxPessoasVisiveis(arr, n));

    return 0;
}
