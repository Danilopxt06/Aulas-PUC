#include <stdio.h>
#include <string.h>

#define MAX 100
#define TAM_EXPR 200

char pilha[MAX][TAM_EXPR];
int topo = -1;

void empilha(char *str) {
    if (topo == MAX - 1) {
        puts("Pilha cheia!");
        return;
    }
    topo++;
    strcpy(pilha[topo], str);
}

void desempilha(char *dest) {
    strcpy(dest, pilha[topo]);
    topo--;
}

int ehOperador(char c) {
    return c == '+' || c == '-' || c == '*' || c == '/' || c == '^';
}

void posfixaParaInfixa(char *posfixa, char *infixa) {
    int i;
    char op1[TAM_EXPR], op2[TAM_EXPR], resultado[TAM_EXPR];
    char operando[2];

    topo = -1;

    for (i = 0; posfixa[i] != '\0'; i++) {
        if (posfixa[i] == ' ')
            continue;

        if (ehOperador(posfixa[i])) {
            // Empilha dois operandos e junta com o operador no meio
            desempilha(op2);
            desempilha(op1);

            sprintf(resultado, "(%s%c%s)", op1, posfixa[i], op2);
            empilha(resultado);
        }
        else {
            operando[0] = posfixa[i];
            operando[1] = '\0';
            empilha(operando);
        }
    }

    desempilha(infixa);
}

int main() {
    char posfixa[MAX];
    char infixa[TAM_EXPR];

    puts("Digite a expressao posfixa:");
    fgets(posfixa, MAX, stdin);
    posfixa[strcspn(posfixa, "\n")] = '\0';

    posfixaParaInfixa(posfixa, infixa);

    printf("Expressao infixa: %s\n", infixa);

    return 0;
}
