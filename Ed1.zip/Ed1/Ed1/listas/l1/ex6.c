#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define MAX 200

char pilha[MAX];
int topo = -1;

void empilha(char c) {
    if (topo == MAX - 1) {
        puts("Pilha cheia!");
        return;
    }
    topo++;
    pilha[topo] = c;
}

char desempilha() {
    return pilha[topo--];
}

int ehPalindromo(char *str) {
    int i;
    char c;

    topo = -1;

    // Empilha todos os caracteres alfanumericos em minusculo
    for (i = 0; str[i] != '\0'; i++) {
        if (isalnum((unsigned char) str[i])) {
            empilha(tolower((unsigned char) str[i]));
        }
    }

    // Desempilhar devolve na ordem inversa: compara com a leitura normal
    for (i = 0; str[i] != '\0'; i++) {
        if (isalnum((unsigned char) str[i])) {
            c = desempilha();
            if (c != tolower((unsigned char) str[i]))
                return 0;
        }
    }

    return 1;
}

int main() {
    char frase[MAX];

    puts("Digite a frase:");
    fgets(frase, MAX, stdin);
    frase[strcspn(frase, "\n")] = '\0';

    if (ehPalindromo(frase))
        puts("Eh um palindromo!");
    else
        puts("Nao eh um palindromo!");

    return 0;
}
