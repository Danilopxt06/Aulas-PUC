#include <stdio.h>
#include <string.h>

#define MAX 100
#define TAM_EXPR 200

char pilha[MAX][TAM_EXPR];
int topo = -1;

void empilha(char *str) {
    if (topo == MAX - 1) {
        puts("Pilha cheia!");
        return;
    }
    topo++;
    strcpy(pilha[topo], str);
}

void desempilha(char *dest) {
    strcpy(dest, pilha[topo]);
    topo--;
}

int ehOperador(char c) {
    return c == '+' || c == '-' || c == '*' || c == '/' || c == '^';
}

// Igual ao postfixo, mas percorrendo a expressao de tras pra frente
void prefixaParaInfixa(char *prefixa, char *infixa) {
    int i, tam;
    char op1[TAM_EXPR], op2[TAM_EXPR], resultado[TAM_EXPR];
    char operando[2];

    topo = -1;
    tam = strlen(prefixa);

    for (i = tam - 1; i >= 0; i--) {
        if (prefixa[i] == ' ')
            continue;

        if (ehOperador(prefixa[i])) {
            desempilha(op1);
            desempilha(op2);

            sprintf(resultado, "(%s%c%s)", op1, prefixa[i], op2);
            empilha(resultado);
        }
        else {
            operando[0] = prefixa[i];
            operando[1] = '\0';
            empilha(operando);
        }
    }

    desempilha(infixa);
}

int main() {
    char prefixa[MAX];
    char infixa[TAM_EXPR];

    puts("Digite a expressao prefixa:");
    fgets(prefixa, MAX, stdin);
    prefixa[strcspn(prefixa, "\n")] = '\0';

    prefixaParaInfixa(prefixa, infixa);

    printf("Expressao infixa: %s\n", infixa);

    return 0;
}
