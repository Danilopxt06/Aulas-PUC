#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 100
#define TAM_TAG 50

char pilha[MAX][TAM_TAG];
int topo = -1;

void empilha(char *tag) {
    if (topo == MAX - 1) {
        puts("Pilha cheia!");
        return;
    }
    topo++;
    strcpy(pilha[topo], tag);
}

char *desempilha() {
    if (topo == -1)
        return NULL;
    return pilha[topo--];
}

int pilhaVazia() {
    return topo == -1;
}

// Extrai o nome da tag, ignorando '/' inicial e atributos
void extraiNomeTag(char *tag, char *nome) {
    int i = 0, j = 0;

    if (tag[i] == '/')
        i++;

    while (tag[i] != '\0' && tag[i] != ' ' && tag[i] != '/') {
        nome[j++] = tag[i++];
    }
    nome[j] = '\0';
}

int parseHTML(char *html) {
    int i = 0;
    int valido = 1;
    char tag[TAM_TAG];
    char nome[TAM_TAG];

    topo = -1;

    while (html[i] != '\0') {
        if (html[i] == '<') {
            int j = 0;
            i++;

            while (html[i] != '>' && html[i] != '\0') {
                tag[j++] = html[i++];
            }
            tag[j] = '\0';

            if (html[i] == '>')
                i++;

            extraiNomeTag(tag, nome);

            if (tag[0] == '/') {
                // Tag de fechamento: parenteses correspondentes
                if (pilhaVazia()) {
                    printf("Erro: tag de fechamento '%s' sem abertura correspondente\n", nome);
                    valido = 0;
                }
                else {
                    char *aberta = desempilha();
                    if (strcmp(aberta, nome) != 0) {
                        printf("Erro: esperava fechar '%s' mas encontrou '%s'\n", aberta, nome);
                        valido = 0;
                    }
                }
            }
            else if (tag[strlen(tag) - 1] != '/') {
                // Ignora tags auto-fechadas, ex: <br/>
                empilha(nome);
            }
        }
        else {
            i++;
        }
    }

    if (!pilhaVazia()) {
        puts("Erro: existem tags nao fechadas");
        valido = 0;
    }

    return valido;
}

int main() {
    char html[500];

    puts("Digite o HTML:");
    fgets(html, 500, stdin);

    if (parseHTML(html))
        puts("HTML valido!");
    else
        puts("HTML invalido!");

    return 0;
}
