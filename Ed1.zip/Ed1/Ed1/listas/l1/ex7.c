#include <stdio.h>

#define MAX 100

int pilha[MAX];
int topo = -1;

void empilha(int i) {
    if (topo == MAX - 1) {
        puts("Pilha cheia!");
        return;
    }
    topo++;
    pilha[topo] = i;
}

int desempilha() {
    return pilha[topo--];
}

int pilhaVazia() {
    return topo == -1;
}

int topoPilha() {
    return pilha[topo];
}

int maior(int a, int b) {
    return a > b ? a : b;
}

// Ideia: pilha de indices com alturas crescentes. Ao achar uma barra
// menor, desempilha e calcula a area usando essa barra como a mais baixa.
int maiorRetangulo(int alturas[], int n) {
    int maiorArea = 0;
    int i, indice, altura, largura, area;

    topo = -1;

    for (i = 0; i < n; i++) {
        while (!pilhaVazia() && alturas[topoPilha()] >= alturas[i]) {
            indice = desempilha();
            altura = alturas[indice];

            if (pilhaVazia())
                largura = i;
            else
                largura = i - topoPilha() - 1;

            area = altura * largura;
            maiorArea = maior(maiorArea, area);
        }

        empilha(i);
    }

    while (!pilhaVazia()) {
        indice = desempilha();
        altura = alturas[indice];

        if (pilhaVazia())
            largura = n;
        else
            largura = n - topoPilha() - 1;

        area = altura * largura;
        maiorArea = maior(maiorArea, area);
    }

    return maiorArea;
}

int main() {
    int alturas[] = {2, 1, 5, 6, 2, 3};
    int n = sizeof(alturas) / sizeof(alturas[0]);

    printf("Maior retangulo: %d\n", maiorRetangulo(alturas, n));

    return 0;
}
