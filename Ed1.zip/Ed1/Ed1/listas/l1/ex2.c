#include <stdio.h>
#include <string.h>

#define MAX 100

char pilha[MAX];
int topo = -1;

void empilha(char c) {
    if (topo == MAX - 1) {
        puts("Pilha cheia!");
        return;
    }
    topo++;
    pilha[topo] = c;
}

char desempilha() {
    return pilha[topo--];
}

char topoPilha() {
    return pilha[topo];
}

int pilhaVazia() {
    return topo == -1;
}

int precedencia(char op) {
    if (op == '^')
        return 3;
    if (op == '*' || op == '/')
        return 2;
    if (op == '+' || op == '-')
        return 1;
    return 0;
}

int ehOperador(char c) {
    return c == '+' || c == '-' || c == '*' || c == '/' || c == '^';
}

void inverte(char *str) {
    int i = 0, j = strlen(str) - 1;
    char tmp;

    while (i < j) {
        tmp = str[i];
        str[i] = str[j];
        str[j] = tmp;
        i++;
        j--;
    }
}

void trocaParenteses(char *str) {
    int i;

    for (i = 0; str[i] != '\0'; i++) {
        if (str[i] == '(')
            str[i] = ')';
        else if (str[i] == ')')
            str[i] = '(';
    }
}

// Algoritmo clássico Infixo -> Posfixo (Shunting-yard)
void infixaParaPosfixa(char *infixa, char *posfixa) {
    int i, j = 0;
    char c;

    topo = -1;

    for (i = 0; infixa[i] != '\0'; i++) {
        c = infixa[i];

        if (c == ' ')
            continue;

        if (c == '(') {
            empilha(c);
        }
        else if (c == ')') {
            while (!pilhaVazia() && topoPilha() != '(') {
                posfixa[j++] = desempilha();
            }
            desempilha(); // remove o '(' correspondente
        }
        else if (ehOperador(c)) {
            while (!pilhaVazia() && topoPilha() != '(' &&
                   precedencia(topoPilha()) >= precedencia(c)) {
                posfixa[j++] = desempilha();
            }
            empilha(c);
        }
        else {
            posfixa[j++] = c;
        }
    }

    while (!pilhaVazia()) {
        posfixa[j++] = desempilha();
    }

    posfixa[j] = '\0';
}

// Passo 1: reverte / Passo 2: troca parenteses /
// Passo 3: converte pra posfixo / Passo 4: reverte de novo
void infixaParaPrefixa(char *infixa, char *prefixa) {
    char invertida[MAX];
    char posfixa[MAX];

    strcpy(invertida, infixa);

    inverte(invertida);
    trocaParenteses(invertida);
    infixaParaPosfixa(invertida, posfixa);
    inverte(posfixa);

    strcpy(prefixa, posfixa);
}

int main() {
    char infixa[MAX];
    char prefixa[MAX];

    puts("Digite a expressao infixa:");
    fgets(infixa, MAX, stdin);
    infixa[strcspn(infixa, "\n")] = '\0';

    infixaParaPrefixa(infixa, prefixa);

    printf("Expressao prefixa: %s\n", prefixa);

    return 0;
}
