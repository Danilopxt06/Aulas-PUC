#include <stdio.h>
#include <string.h>

#define MAX 100

char pilha[MAX];
int topo = -1;

void empilha(char c) {
    if (topo == MAX - 1) {
        puts("Pilha cheia!");
        return;
    }
    topo++;
    pilha[topo] = c;
}

char desempilha() {
    return pilha[topo--];
}

int pilhaVazia() {
    return topo == -1;
}

char topoPilha() {
    return pilha[topo];
}

// Mantem a pilha em ordem crescente: remove os digitos maiores a
// esquerda enquanto sobrar k remocoes disponiveis
void removeKDigitos(char *num, int k, char *resultado) {
    int i;
    int tam = strlen(num);

    topo = -1;

    for (i = 0; i < tam; i++) {
        while (!pilhaVazia() && k > 0 && topoPilha() > num[i]) {
            desempilha();
            k--;
        }
        empilha(num[i]);
    }

    // Se ainda sobrou k, remove do final (a pilha estava crescente)
    while (k > 0) {
        desempilha();
        k--;
    }

    for (i = 0; i <= topo; i++) {
        resultado[i] = pilha[i];
    }
    resultado[topo + 1] = '\0';

    // Remove zeros a esquerda
    i = 0;
    while (resultado[i] == '0' && resultado[i + 1] != '\0')
        i++;

    if (i > 0)
        memmove(resultado, resultado + i, strlen(resultado) - i + 1);

    if (resultado[0] == '\0') {
        resultado[0] = '0';
        resultado[1] = '\0';
    }
}

int main() {
    char num[MAX];
    char resultado[MAX];
    int k;

    puts("Digite o numero:");
    fgets(num, MAX, stdin);
    num[strcspn(num, "\n")] = '\0';

    puts("Digite o valor de k:");
    scanf("%d", &k);

    removeKDigitos(num, k, resultado);

    printf("Resultado: %s\n", resultado);

    return 0;
}
