#include <stdio.h>

#define TAM 5

int inicio = 0;
int fim = 0;
int quantidade = 0;

int fila[TAM];

int enfila(int num) {
    if (quantidade == TAM) {
        printf("Fila cheia!\n");
        return 0;
    }

    fila[fim] = num;
    fim = (fim + 1) % TAM;
    quantidade++;

    return 1;
}

int desenfila(int *valor) {
    if (quantidade == 0) {
        printf("Fila vazia!\n");
        return 0;
    }

    printf("Removendo da posicao %d\n", inicio);

    *valor = fila[inicio];
    inicio = (inicio + 1) % TAM;
    quantidade--;

    printf("Novo inicio: %d\n", inicio);

    return 1;
}

int main() {
    int num;
    int valor;
    int op;

    do {
        puts("\n1 - Enfileirar");
        puts("2 - Desenfileirar");
        puts("3 - Sair");
        printf("Escolha uma opcao: ");
        scanf("%d", &op);

        switch (op) {
            case 1:
                printf("Digite o numero a ser enfileirado: ");
                scanf("%d", &num);

                enfila(num);
                break;

            case 2:
                if (desenfila(&valor)) {
                    printf("Numero removido: %d\n", valor);
                }
                break;

            case 3:
                printf("Saindo...\n");
                break;

            default:
                printf("Opcao invalida!\n");
        }

    } while (op != 3);

    return 0;
}