#include <stdio.h>

#define TAM 5

int inicio = 0;
int fim = 0;

int filadaputa[TAM];

int fila(int num) {

    filadaputa[fim] = num;
    fim++;

    return 1;
}

int desfila() {

    int valor = filadaputa[inicio];
    inicio++;

    return valor;
}

int main() {
    int num, i;
    int op;
    do{
        switch(op)
        {
            case 1:
                puts("Digite os números a serem enfileirado:\n");
                for (i = 0; i < TAM; i++){
                    scanf("%d", &num);
                    fila(num);
                    puts("\n");
                }
                break;
            case 2:
                printf("%d\n", desfila());
                break;
            case 3:
                op=0;
                break;
            default:
                op=0;
        }
        puts("1 - Enfileirar");
        puts("2 - desinfileirar");
        puts("3 - Sair\n");
        scanf("%d", &op);
    } while (op!=0);
    return 0;
}

