; PUC GOIAS - ESCOLA POLITECNICA - CIENCIA DA COMPUTACAO
; DANILO ANTHONY PEIXOTO LIMA
; 16-09-2026
; QUARTO PROGRAMA: IF.S

section .data
mens db "digite algo", 10           ; Cria string inicial
tam equ $-mens                      ; Calcula tamanho inicial

msgp db "primeira letra e P", 10    ; Cria string verdadeira
tamp equ $-msgp                     ; Tamanho string verdadeira

msgnaop db "primeira letra nao e P", 10 ; Cria string falsa
tamnaop equ $-msgnaop               ; Tamanho string falsa

segment .bss
buf resb 100                        ; Reserva memória texto
qtd resd 1                          ; Reserva tamanho lido

segment .text
global _start                       ; Define entrada global
_start:                             ; Início do programa

mov edx, tam                        ; Tamanho texto tela
mov ecx, mens                       ; Ponteiro texto tela
mov ebx, 1                          ; Saída para tela
mov eax, 4                          ; Comando de escrita
int 80h                             ; Executa a escrita

mov edx, 100                        ; Limite leitura teclado
mov ecx, buf                        ; Destino leitura teclado
mov ebx, 0                          ; Entrada do teclado
mov eax, 3                          ; Comando de leitura
int 80h                             ; Executa a leitura

mov [qtd], eax                      ; Salva bytes lidos

cmp byte[buf], "P"                  ; Compara primeira letra
je mp                               ; Pula se igual
jne mnao                            ; Pula se diferente

mnao:                               ; Bloco do diferente
mov edx, tamnaop                    ; Tamanho msg falsa
mov ecx, msgnaop                    ; Ponteiro msg falsa
mov ebx, 1                          ; Saída para tela
mov eax, 4                          ; Comando de escrita
int 80h                             ; Executa a escrita
jmp fim                             ; Pula para fim

mp:                                 ; Bloco do igual
mov edx, tamp                       ; Tamanho msg verdadeira
mov ecx, msgp                       ; Ponteiro msg verdadeira
mov ebx, 1                          ; Saída para tela
mov eax, 4                          ; Comando de escrita
int 80h                             ; Executa a escrita

fim:                                ; Bloco de saída
mov eax, 1                          ; Comando de encerramento
mov ebx, 0                          ; Código de sucesso
int 80h                             ; Encerra o programa