segment .data
    nomearq db "texto1.txt", 0     ; NOME DO ARQUIVO
    merro db "erro...", 10     ; MENSAGEM DE ERRO
    tam equ $-merro            ; TAMANHO DO ERRO
    salta db 10                ; QUEBRA DE LINHA

segment .bss
    fd resd 1                  ; DESCRITOR DO ARQUIVO
    buff resb 20               ; BUFFER DE LEITURA
    qtd resd 1                 ; QUANTIDADE DE BYTES

segment .text
exibir:
    mov ebx, 1                 ; SAÍDA PADRÃO STDOUT
    mov eax, 4                 ; SYSCALL SYS_WRITE
    int 80h                    ; INTERRUPÇÃO DO SISTEMA
    ret                        ; RETORNA DA FUNÇÃO

ler:
    mov ebx, [fd]              ; ARQUIVO PARA LER
    mov ecx, buff              ; ENDEREÇO DO BUFFER
    mov eax, 3                 ; SYSCALL SYS_READ
    int 80h                    ; INTERRUPÇÃO DO SISTEMA
    ret                        ; RETORNA DA FUNÇÃO

erroab:
    mov ecx, merro             ; APONTA MENSAGEM ERRO
    mov edx, tam               ; TAMANHO DA MENSAGEM
    call exibir                ; CHAMA FUNÇÃO EXIBIR
    jmp fim                    ; FINALIZA O PROGRAMA

abrir:
    mov ebx, nomearq           ; NOME DO ARQUIVO
    mov ecx, 0                 ; MODO SOMENTE LEITURA
    mov edx, 777q              ; PERMISSÕES DO ARQUIVO
    mov eax, 5                 ; SYSCALL SYS_OPEN
    int 80h                    ; INTERRUPÇÃO DO SISTEMA
    ret                        ; RETORNA DA FUNÇÃO

fechar:
    mov ebx, [fd]              ; ARQUIVO PARA FECHAR
    mov eax, 6                 ; SYSCALL SYS_CLOSE
    int 80h                    ; INTERRUPÇÃO DO SISTEMA
    ret                        ; RETORNA DA FUNÇÃO

fim:
    mov eax, 1                 ; SYSCALL SYS_EXIT
    int 80h                    ; INTERRUPÇÃO DO SISTEMA

global _start
_start:
    call abrir                 ; ABRE O ARQUIVO
    cmp eax, 0                 ; VERIFICA SUCESSO ABERTURA
    jl erroab                  ; DESVIA SE ERRO
    mov [fd], eax              ; SALVA DESCRITOR ARQUIVO
    mov edx, 20                ; LIMITE DE BYTES
    call ler                   ; LÊ O ARQUIVO
    mov [qtd], eax             ; SALVA BYTES LIDOS
    mov ecx, buff              ; APONTA PARA BUFFER
    mov edx, [qtd]             ; DEFINE BYTES LIDOS
    call exibir                ; EXIBE TEXTO LIDO
    mov ecx, salta             ; APONTA NOVA LINHA
    mov edx, 1                 ; UM BYTE APENAS
    call exibir                ; EXIBE NOVA LINHA
    call fechar                ; FECHA O ARQUIVO
    jmp fim                    ; FINALIZA O PROGRAMA
