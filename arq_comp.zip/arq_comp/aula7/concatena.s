; PUC GOIAS - ESCOLA POLITECNICA - CIENCIA DA COMPUTACAO
; DANILO ANTHONY PEIXOTO LIMA
; 14-10-2026
; SETIMO PROGRAMA: CONCATENA.S

_start:
mov eax, 5            ; Comando para abrir arquivo (sys_open)
mov ebx, nome         ; Arquivo digitado pelo usuario
int 80h               ; Tenta abrir

; ERRO?
cmp eax, 0            ; Verifica se o Kernel retornou erro (valor < 0)
jl erro_abertura      ; Se deu erro (S), pula para exibir a MER

; RAMIFICACAO: NAO DEU ERRO (N)
ler_arquivo:          
mov eax, 3            ; Comando de leitura (sys_read)
int 80h               ; LER para o BUFFER

mov eax, 4            ; Comando de escrita (sys_write)
int 80h               ; EXIBE o que foi lido do buffer

mov eax, 6            ; Comando para fechar arquivo (sys_close)
int 80h               ; FECHA
jmp fim               ; Pula para o fim

; RAMIFICAÇÃO: DEU ERRO (S)
erro_abertura:
mov eax, 4            ; Comando de escrita (sys_write)
mov ecx, msg_erro     ; MER (Mensagem de Erro: "Erro ao abrir!")
int 80h               ; EXIBE o erro

fim:                  ; FIM
mov eax, 1            ; sys_exit
int 80h