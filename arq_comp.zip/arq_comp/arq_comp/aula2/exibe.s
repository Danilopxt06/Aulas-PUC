; PUC GOIAS - ESCOLA POLITECNICA - CIENCIA DA COMPUTACAO
; DANILO ANTHONY PEIXOTO LIMA
; 19-08-2026
; SEGUNDO PROGRAMA: EXIBE.S

segment .data
mens db "Hello, World!", 10
tam equ $ -mens ;TAMANHO DA MENSAGEM

segment .text
global _start

_start: ; PONTO DE ENTRADA

    ; MOSTRANDO A STRING NA TELA
    ;mov edx, 14        ; TAMANHO DA STRING
    mov edx, tam        ; TAMANHO DA STRING
    mov ecx, mens      ; PONTEIRO DE TEXTO
    mov ebx, 1         ; FD DA TELA
    mov eax, 4         ; SERVIÇO PRINT
    int 80h             ; CHAMADA AO KERNEL

sair:
    mov eax, 1         ; SERVIÇO EXIT
    mov ebx, 0         ; CÓDIGO DE SAÍDA
    int 80h             ; CHAMADA AO KERNEL
