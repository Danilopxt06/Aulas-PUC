; PUC GOIAS - ESCOLA POLITECNICA - CIENCIA DA COMPUTACAO
; DANILO ANTHONY PEIXOTO LIMA
; 09-09-2026
; TERCEIRO PROGRAMA: RECEBESTR.S

section .data
mens db "digite algo", 10
tam equ $-mens

segment .bss
buf resb 100
qtd resd 1

segment .text
global _start
_start:         ;ENTRADA

;"IMPRIMIR" A STRING
mov edx, tam    ;TAMANHO
mov ecx, mens   ;PONTEIRO
mov ebx, 1      ;FD DA TELA
mov eax, 4      ;SERVIÇO PRINT
int 80h

;RECEBER A STRING
mov edx, 100    ;Nº DE CARACTERES
mov ecx, buf    ;DESTINO
mov ebx, 0      ;TECLADO
mov eax, 3      ;SERVIÇO READ
int 80h

mov [qtd], eax

;IMPRIMINDO O "ALGO"
mov edx, [qtd]
mov ecx, buf
mov ebx, 1
mov eax, 4
int 80h

sai:
mov eax, 1      ;SERVIÇO EXIT
int 80h