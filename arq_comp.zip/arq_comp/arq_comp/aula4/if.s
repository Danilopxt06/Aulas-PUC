; PUC GOIAS - ESCOLA POLITECNICA - CIENCIA DA COMPUTACAO
; DANILO ANTHONY PEIXOTO LIMA
; 16-09-2026
; QUARTO PROGRAMA: IF.S

section .data
mens db "digite algo", 10
tam equ $-mens

msgp db "primeira letra e P", 10
tamp equ $-msgp

msgnaop db "primeira letra nao e P", 10
tamnaop equ $-msgnaop

segment .bss
buf resb 100
qtd resd 1

segment .text
global _start
_start:             ;ENTRADA

; "IMPRIMIR" A STRING
mov edx, tam        ; TAMANHO
mov ecx, mens       ; PONTEIRO
mov ebx, 1          ; FD DA TELA
mov eax, 4          ; SERVIÇO PRINT
int 80h

; RECEBER A STRING
mov edx, 100        ; Nº DE CARACTERES
mov ecx, buf        ; DESTINO
mov ebx, 0          ; TECLADO
mov eax, 3          ; SERVIÇO READ
int 80h

mov [qtd], eax      ; GUARDA A QUANTIDADE DE CARACTERES LIDOS

; CONDICIONAL
cmp byte[buf], "P"  ; COMPARA O PRIMEIRO ENDEREÇO DA STRING LIDA COM "P"
je mp               ; SE FOR P, VAI PARA MP
jne mnao            ; SE FOR DIFERENTE, VAI PARA MNAO

mnao:               ; SALTO SE FOR DIFERNTE
mov edx, tamnaop    ; TAMANHO DA MENSAGEM
mov ecx, msgnaop    ; ENDEREÇO DA MENSAGEM
mov ebx, 1          ; STDOUT
mov eax, 4          ; SYS_WRITE
int 80h

jmp fim             ; PULA PARA O BLOCO DO IF


mp:
mov edx, tamp       ; TAMANHO DA MENSAGEM
mov ecx, msgp       ; ENDEREÇO DA MENSAGEM
mov ebx, 1          ; STDOUT
mov eax, 4          ; SYS_WRITE
int 80h

fim:                ; SALTA PARA O FINAL

mov eax, 1          ; SERVIÇO EXIT
mov ebx, 0          ; CÓDIGO DE SAÍDA
int 80h