; PUC GOIAS - ESCOLA POLITECNICA - CIENCIA DA COMPUTACAO
; DANILO ANTHONY PEIXOTO LIMA
; 23-09-2026
; QUINTO PROGRAMA: FOR.S

section .data

mens db "digite algo: ", 10
tam equ $-mens

msgcopia db "Voce digitou: "
tamcopia equ $-msgcopia


section .bss

buf resb 100
copia resb 100
qtd resd 1


section .text

global _start

_start:

; IMPRIMIR A MENSAGEM
mov edx, tam        ; TAMANHO DA MENSAGEM
mov ecx, mens       ; ENDERECO DA MENSAGEM
mov ebx, 1          ; STDOUT
mov eax, 4          ; SYS_WRITE
int 80h


; RECEBER A STRING
mov edx, 100        ; NUMERO MAXIMO DE CARACTERES
mov ecx, buf        ; DESTINO
mov ebx, 0          ; STDIN
mov eax, 3          ; SYS_READ
int 80h

mov [qtd], eax      ; GUARDA A QUANTIDADE DE CARACTERES LIDOS

mov esi, 0          ; I = 0


; REPETICAO FOR
for:

cmp esi, [qtd]      ; COMPARA I COM QTD
jge fim_for         ; SE I >= QTD, TERMINA

mov al, [buf + esi] ; PEGA buf[I]
mov [copia + esi], al ; copia[I] = buf[I]

inc esi             ; I++

jmp for             ; VOLTA PARA O FOR


fim_for:


; IMPRIMIR A MENSAGEM
mov edx, tamcopia
mov ecx, msgcopia
mov ebx, 1
mov eax, 4
int 80h


; IMPRIMIR STRING COPIADA
mov edx, [qtd]      ; QUANTIDADE DE CARACTERES
mov ecx, copia      ; ENDERECO DA COPIA
mov ebx, 1          ; STDOUT
mov eax, 4          ; SYS_WRITE
int 80h


; FINALIZAR PROGRAMA
fim:

mov eax, 1          ; SYS_EXIT
mov ebx, 0          ; CODIGO DE SAIDA
int 80h