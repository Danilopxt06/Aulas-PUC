; PUC GOIAS - ESCOLA POLITECNICA - CIENCIA DA COMPUTACAO
; DANILO ANTHONY PEIXOTO LIMA
; 30-09-2026
; SEXTO PROGRAMA: WHILE

section .data

mens db "digite algo: ", 10
tam equ $-mens

msgcopia db "Voce digitou: "
tamcopia equ $-msgcopia


section .bss

buf resb 100
copia resb 100
qtd resd 1


section .text

global _start

_start:

; IMPRIMIR A MENSAGEM
mov edx, tam
mov ecx, mens
mov ebx, 1
mov eax, 4
int 80h


; RECEBER A STRING
mov edx, 100
mov ecx, buf
mov ebx, 0
mov eax, 3
int 80h

mov [qtd], eax              ; GUARDA A QUANTIDADE DE CARACTERES LIDOS

mov esi, 0                  ; I = 0


; DO WHILE
do_while:

mov al, [buf + esi]         ; PEGA BUF[I]
mov [copia + esi], al       ; COPIA[I] = BUF[I]

inc esi                     ; I++

cmp esi, [qtd]              ; COMPARA I COM QTD
jl do_while                 ; SE I < QTD, REPETE


; IMPRIMIR A MENSAGEM
mov edx, tamcopia
mov ecx, msgcopia
mov ebx, 1
mov eax, 4
int 80h


; IMPRIMIR STRING COPIADA
mov edx, [qtd]
mov ecx, copia
mov ebx, 1
mov eax, 4
int 80h


; FINALIZAR PROGRAMA
fim:

mov eax, 1
mov ebx, 0
int 80h